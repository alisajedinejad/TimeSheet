package Main;

import Terminals.Terminal;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class TestCase {

  public static void main(String[] args) throws ParserConfigurationException, IOException, SAXException, TransformerException, InterruptedException {
    final int count=new File("terminalsInfo").listFiles().length;

    final Terminal threads[] = new Terminal[count];


//System.out.println(count);

    for(int i = 0; i <count; i++) {
      threads[i] = new Terminal(8080,"127.0.0.1",i,1);
      threads[i].start();

    }



  }
}
