package Main;


import Server.MainServer;
import java.io.IOException;

public class Main {

  public static void main(String[] args) throws IOException {

    MainServer server = new MainServer(8080);







  }
}
