package ExeptionHandler;

public class NegativeDurationInDays extends Exception {
  public NegativeDurationInDays() {
  }

  public NegativeDurationInDays(String customerNumber) {
    super("Account that has customer number " + customerNumber + " has zero or negative Duration in Days");
  }
}
