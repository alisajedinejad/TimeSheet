package ExeptionHandler;

import java.math.BigDecimal;

public class CheckNegativeDepositBalance extends NegativeDepositBalance {
  public CheckNegativeDepositBalance() {
  }

  public CheckNegativeDepositBalance(BigDecimal depositBalance, String CustomerNumber) throws NegativeDepositBalance {
    if (depositBalance.compareTo(new BigDecimal("0")) != -1) {

    } else {
      throw new NegativeDepositBalance(CustomerNumber);


    }

  }
}
