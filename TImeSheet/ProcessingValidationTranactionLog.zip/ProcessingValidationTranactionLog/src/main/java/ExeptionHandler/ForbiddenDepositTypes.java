package ExeptionHandler;

public class ForbiddenDepositTypes extends Exception {
  public ForbiddenDepositTypes() {
  }

  public ForbiddenDepositTypes(String customerNumber) {
    super("Account that has customer number " + customerNumber + " has illegal deposit type ");
  }
}
