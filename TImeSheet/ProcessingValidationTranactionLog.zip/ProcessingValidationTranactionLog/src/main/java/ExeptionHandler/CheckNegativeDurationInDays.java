package ExeptionHandler;

public class CheckNegativeDurationInDays extends Exception {
  public CheckNegativeDurationInDays() {
  }

  public CheckNegativeDurationInDays(int DurationInDays, String customerNumber) throws NegativeDurationInDays {
    if (DurationInDays >= 1) {
    } else {
      throw new NegativeDurationInDays(customerNumber);
    }
  }
}
