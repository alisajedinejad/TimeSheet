package ExeptionHandler;

public class CheckForbiddenDepositTypes extends ForbiddenDepositTypes {
  public CheckForbiddenDepositTypes(String depositType, String customerNumber) throws ForbiddenDepositTypes {
    if (depositType.equals("ShortTerm") || depositType.equals("LongTerm") || depositType.equals("Qarz")) {
    } else {
      throw new ForbiddenDepositTypes(customerNumber);
    }
  }


}
