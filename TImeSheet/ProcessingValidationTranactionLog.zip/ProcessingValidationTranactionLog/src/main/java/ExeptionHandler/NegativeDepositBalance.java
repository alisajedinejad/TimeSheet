package ExeptionHandler;

public class NegativeDepositBalance extends Exception {
  public NegativeDepositBalance() {
  }

  public NegativeDepositBalance(String customerNumber) {
    super("Account that has customer number " + customerNumber + " has negative balance");
  }
}
