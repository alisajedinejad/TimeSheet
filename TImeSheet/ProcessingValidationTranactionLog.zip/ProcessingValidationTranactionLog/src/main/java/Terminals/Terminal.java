package Terminals;

import Model.WriteToXML;
import Model.XMLDataReading;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.concurrent.TimeUnit;

public class Terminal extends Thread {

  private int Port;
  private String Ip;
  private int TerminalId;
  private  Socket socket;
  int error1 = 0;
  int error2 = 0;
  int runCount = 0;
  DataInputStream dis;
  DataOutputStream dos;
  int close=0;
  int sync=0;

  public Terminal(int Port, String Ip, int id,int sync) throws ParserConfigurationException, TransformerException, SAXException, IOException {
    this.Ip = Ip;
    this.Port = Port;
    this.TerminalId = id;
    this.sync = sync;
    WriteToXML WTX = new WriteToXML("terminalsInfo/terminal" + this.TerminalId + ".xml");

    WTX.SetIp(this.Ip,this);
    WTX.SetPort(String.valueOf(this.Port),this);

  }


  public void run() {

    runCount++;
    System.out.println("///////////////////////////////////////first in run " + socket+" agent is : "+this);

    XMLDataReading WTX = new XMLDataReading("terminalsInfo/terminal" + this.TerminalId + ".xml");
    String Commands[][] = WTX.getOutPut();

    System.out.println("call run by thread , socket is :" + socket + "  commands size is : " + Commands.length + " for agent "+this);
    InetAddress address = null;


    for (int i = 0; i < Commands.length; i++) {

//      System.out.println("heeereeeeeeeeee fooooorrrrrrr "+Commands[i][3]);
      socket=null;

      try {
        address = InetAddress.getByName(Ip);
      } catch (UnknownHostException e) {
        e.printStackTrace();
      }

      try {
        socket = new Socket(address, Port);
      } catch (IOException e) {
        e.printStackTrace();
      }
      try {

        dis=null;
        dos=null;


        System.out.println("///////////////////////////////////////open socket for socket " + socket+"  agent : "+this +" for command number "+i);


        //Send the message to the server
        dis = new DataInputStream(socket.getInputStream());
        dos = new DataOutputStream(socket.getOutputStream());




        String CommandsSend = Commands[i][0] + "@" + Commands[i][1] + "@" + Commands[i][2] + "@" + Commands[i][3] +"@"+sync+" \n";

        dos.writeUTF(CommandsSend);


        System.out.println("Command sent to the server " + CommandsSend + " from terminal socket " + socket+" and agent "+this);

        //Get the return message from the server
        String message = dis.readUTF();
        System.out.println("Message received from the server : " + message+" for agent "+this+" for command number " +i+" for command "+CommandsSend);
        System.out.println("close is : " + close);
        System.out.println("command length is : " + Commands.length);
        if(message.equals("done"+" \n")){
          close++;
            System.out.println("////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////kheyli");
            try {
              dis.close();
            } catch (IOException e) {
              e.printStackTrace();
            }
            try {
              dos.close();
            } catch (IOException e) {
              e.printStackTrace();
            }
            socket.close();
            System.out.println("//////////////////////////////socket "+socket+" close for agent "+this+" for command number "+i);
          if(close==Commands.length){
            System.out.println("//////////////////////////////agent "+this+" join ");

//              this.join();
          }


        }
        else{
          System.out.println("Message received from the server whit sleep: " + message+" for agent "+this+" for command number " +i +"in sleep");

//          TimeUnit.MILLISECONDS.sleep(10);
//          socket=null;
//          socket = new Socket(address, Port);
//          dis=null;
//          dos=null;
//
//
//          System.out.println("///////////////////////////////////////open socket for socket " + socket+"  agent : "+this +" for command number "+i);
//
//
//          //Send the message to the server
//          dis = new DataInputStream(socket.getInputStream());
//          dos = new DataOutputStream(socket.getOutputStream());
//
//          dos.writeUTF(CommandsSend);
//          System.out.println("Command sent to the server " + CommandsSend + " from terminal socket " + socket+" and agent "+this+" from sleep");



        }


      } catch (Exception exception) {
        System.out.println("ali error 1 : " + exception);
        System.out.println("ali error 1 socket: " + socket+" for agent "+ this +" for command number "+i);
        error1++;
        exception.printStackTrace();

      }
    }


  }

  public void getErr() {
    System.out.println(error1 + "       " + error2);
  }
  public void getRunCount() {
    System.out.println("getRunCount: "+this.runCount);
  }
  public void isClose() {
    System.out.println(socket.isClosed());
  }



}
