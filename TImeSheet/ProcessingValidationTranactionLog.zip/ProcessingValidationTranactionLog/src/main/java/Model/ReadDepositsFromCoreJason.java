package Model;

import com.eclipsesource.json.Json;
import com.eclipsesource.json.JsonArray;
import com.eclipsesource.json.JsonObject;

import java.io.IOException;

public class ReadDepositsFromCoreJason {

  private JsonObject CoreObject=new JsonObject();
  private JsonArray  deposits=new JsonArray();

  public ReadDepositsFromCoreJason() throws IOException {

    Model.FileReader FR = new FileReader("core.json");

    String json=FR.FileToString();
    this.CoreObject = Json.parse(json).asObject();
    this.deposits = this.CoreObject.get("deposits").asArray();



  }

  public JsonArray getDeposits(){
    return this.deposits;

  }
  public JsonObject getMainObject(){
    return this.CoreObject;

  }


  public void Print(){
    System.out.println(deposits.size());
  }




}
