package Model;

import com.eclipsesource.json.Json;
import com.eclipsesource.json.JsonArray;
import com.eclipsesource.json.JsonObject;

import java.io.*;

public class WriteToCoreJason {

  private JsonObject CoreObject = new JsonObject();

  public WriteToCoreJason() throws IOException {
    FileReader FR = new FileReader("core.json");

    String json=FR.FileToString();

    this.CoreObject = Json.parse(json).asObject();

  }

  public void setPort(int Port) throws IOException {
    this.CoreObject.set("port", Port);
    String s =CoreObject.toString();
   FileWriteToCore FRTC =new FileWriteToCore(s);
   FRTC.FileToString();


  }


  public void Print() {
    System.out.println(CoreObject);
  }


}
