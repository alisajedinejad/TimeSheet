package Model;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.IOException;

public class WriteToXML {
  private String Path;


  public WriteToXML(String Path){
    this.Path=Path;

  }

  public void SetIp(String Ip,Object t) throws ParserConfigurationException, IOException, SAXException, TransformerException {
    DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
    DocumentBuilder docBuilder;
    docBuilder = docFactory.newDocumentBuilder();
    Document doc = docBuilder.parse(this.Path);

    /**
     * Get the param from xml and set value
     */
    Node search = doc.getElementsByTagName("server").item(0);
    NamedNodeMap attr = search.getAttributes();
    Node nodeAttr = attr.getNamedItem("ip");
    nodeAttr.setTextContent(Ip);

    /**
     * write it back to the xml
     */
    TransformerFactory transformerFactory = TransformerFactory.newInstance();
    Transformer transformer = transformerFactory.newTransformer();
    DOMSource source = new DOMSource(doc);
    StreamResult result = new StreamResult(new File(this.Path));
    transformer.transform(source, result);

    System.out.println("Set client Ip "+Ip+" for agent "+t);

  }
  public void SetPort(String Port,Object t) throws ParserConfigurationException, IOException, SAXException, TransformerException {
    DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
    DocumentBuilder docBuilder;
    docBuilder = docFactory.newDocumentBuilder();
    Document doc = docBuilder.parse(this.Path);

    /**
     * Get the param from xml and set value
     */
    Node search = doc.getElementsByTagName("server").item(0);
    NamedNodeMap attr = search.getAttributes();
    Node nodeAttr = attr.getNamedItem("port");
    nodeAttr.setTextContent(Port);

    /**
     * write it back to the xml
     */
    TransformerFactory transformerFactory = TransformerFactory.newInstance();
    Transformer transformer = transformerFactory.newTransformer();
    DOMSource source = new DOMSource(doc);
    StreamResult result = new StreamResult(new File(this.Path));
    transformer.transform(source, result);

    System.out.println("Set client port "+Port+" for agent "+t);
  }


}
