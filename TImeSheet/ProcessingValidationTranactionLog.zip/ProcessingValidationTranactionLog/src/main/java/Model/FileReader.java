package Model;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;

public class FileReader {
private String Address;


public FileReader(String Add){
  this.Address=Add;
  }

public String FileToString() throws IOException {
  File file = new File(this.Address);

  BufferedReader br = new BufferedReader(new java.io.FileReader(file));

  String st;
  String string="";
  while ((st = br.readLine()) != null){
    string+=st;
  }
  return string;
}



}
