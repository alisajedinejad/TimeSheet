package Model;

import java.io.IOException;
import java.io.PrintWriter;

public class FileWriteToCore {
private String json;


public FileWriteToCore(String json){
  this.json=json;
  }

public void FileToString() throws IOException {
  PrintWriter writer = new PrintWriter("core.json", "UTF-8");
  writer.println(this.json);
  writer.close();
  System.out.println("Success set new port");
}



}
