package Model;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;

public class XMLDataReading {

  private String OutPut[][];
  private String Address;

  public XMLDataReading(String Address) {
    this.Address = Address;
  }


  public String[][] getOutPut() {
    try {

      File fXmlFile = new File(Address);
      DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
      Document doc = dBuilder.parse(fXmlFile);

      doc.getDocumentElement().normalize();

      NodeList nList = doc.getElementsByTagName("transaction");
      OutPut = new String[nList.getLength()][4];

      for (int i = 0; i < nList.getLength(); i++) {

        Node nNode = nList.item(i);

        if (nNode.getNodeType() == Node.ELEMENT_NODE) {

          Element eElement = (Element) nNode;

          OutPut[i][0] =(eElement.getAttribute("amount"));
          OutPut[i][1] =(eElement.getAttribute("type"));
          OutPut[i][2] =(eElement.getAttribute("deposit"));
          OutPut[i][3] =(eElement.getAttribute("id"));

        }
      }

    } catch (ParserConfigurationException e) {
      System.out.println("ParserConfigurationException");
      e.printStackTrace();
    } catch (IOException e) {
      System.out.println("IOException");
      e.printStackTrace();
    } catch (SAXException e) {
      System.out.println("SAXException");
      e.printStackTrace();
    }

    return OutPut;
  }


}