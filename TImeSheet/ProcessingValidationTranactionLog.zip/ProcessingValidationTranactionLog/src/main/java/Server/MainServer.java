package Server;

import Model.FileWriteToCore;
import Model.ReadDepositsFromCoreJason;
import Model.WriteToCoreJason;
import com.eclipsesource.json.JsonArray;
import com.eclipsesource.json.JsonObject;
import com.eclipsesource.json.JsonValue;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class MainServer {
  private int port;
  private JsonArray deposits;
  private JsonObject object;
  int count=0;
  Socket socket ;



  public MainServer(int port) throws IOException {
    this.port = port;
    WriteToCoreJason WTCJ = new WriteToCoreJason();
    WTCJ.setPort(port);
    ReadDepositsFromCoreJason RDFCJ = new ReadDepositsFromCoreJason();
    this.deposits = RDFCJ.getDeposits();
    this.object = RDFCJ.getMainObject();

    ServerSocket serverSocket = new ServerSocket(port);
    System.out.println("Server Started and listening to the port " + this.port);



    while (true) {



      try
      {
        // socket object to receive incoming client requests
        socket = serverSocket.accept();

        System.out.println("A new client is connected : " + socket);

        // obtaining input and out streams
        DataInputStream dis = new DataInputStream(socket.getInputStream());
        DataOutputStream dos = new DataOutputStream(socket.getOutputStream());


        // create a new thread object
        System.out.println("Assigning new thread for this client thread number "+this.count);

        Thread t= new ClientHandler(socket, dis, dos,deposits,object);




        // Invoking the start() method
        t.start();
//        System.out.println("c "+count);
//
        this.count++;
      }
      catch (Exception e){
        socket.close();
        e.printStackTrace();
      }


    }


//      criticalSection(serverSocket);



  }





}
