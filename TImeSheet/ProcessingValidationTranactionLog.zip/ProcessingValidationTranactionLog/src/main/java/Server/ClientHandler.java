package Server;

import Model.FileWriteToCore;
import com.eclipsesource.json.JsonArray;
import com.eclipsesource.json.JsonObject;
import com.eclipsesource.json.JsonValue;

import java.io.*;
import java.net.Socket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

// ClientHandler class
class ClientHandler extends Thread
{
  DateFormat fordate = new SimpleDateFormat("yyyy/MM/dd");
  DateFormat fortime = new SimpleDateFormat("hh:mm:ss");
  final DataInputStream dis;
  final DataOutputStream dos;
  final Socket socket;
  private JsonArray deposits;
  private JsonObject object;
  public static boolean isSnchronized[]=new boolean[1000];
  public int count=0;
  public int count2=0;
  public String msg=null;

  // Constructor
  public ClientHandler(Socket s, DataInputStream dis, DataOutputStream dos,JsonArray d,JsonObject o) throws IOException {
    this.socket = s;
    this.dis = dis;
    this.dos = dos;
    this.deposits=d;
    this.object=o;
    msg = this.dis.readUTF();

  }

  @Override
  public  void run()
  {
    System.out.println(count2+"hello im in run with socket "+this.socket+" and dis "+this.dis+" and dos "+this.dos+" and obj "+this.object+" and deposit "+this.deposits+" is closed"+this.socket.isClosed()+" and this is "+this);


    count++;
    count2++;
    String toReturn;

    try {

        // receive the answer from client
//      String temp=this.dis.readUTF();
//      String temp2=this.dis.readUTF();

      System.out.println("in run for time :" + count+" msg is "+msg);

      System.out.println("receive the answer from client : "+msg + " ; socket is : "+socket);
        String[] arrOfStr = msg.split("@", 5);
        String id = (arrOfStr[3]);
        int amount = Integer.parseInt(arrOfStr[0].replace(",", ""));
        String command = arrOfStr[1];
        String depositId = arrOfStr[2];
        String sync = (arrOfStr[4]);
//
//        int sync=0;

//        System.out.println("here is sync is "+arrOfStr[4]);
if(sync.equals("0 \n")) {
  System.out.println("here is in if "+sync);

  if (command.equals("deposit")) {
    System.out.println(" deposit command");

    for (JsonValue item : deposits) {
      String idInCore = item.asObject().getString("id", "Unknown Item");


      if (idInCore.equals(depositId)) {

        int newAmount = amount + Integer.parseInt(item.asObject().getString("initialBalance", "Unknown Item").replace(",", ""));
        int upperBound = Integer.parseInt(item.asObject().getString("upperBound", "Unknown Item").replace(",", ""));
        if (newAmount <= upperBound) {

          item.asObject().set("initialBalance", Integer.toString(newAmount));
          String write = object.toString();
          FileWriteToCore FRTC = new FileWriteToCore(write);
          FRTC.FileToString();

          System.out.println("log success add");
        } else {
          System.out.println("log upper bound illegal");

        }

      }

    }

  } else if (command.equals("withdraw")) {
    System.out.println("withdraw");

    for (JsonValue item : deposits) {
      String idInCore = item.asObject().getString("id", "Unknown Item");


      if (idInCore.equals(depositId)) {

        int Amount = Integer.parseInt(item.asObject().getString("initialBalance", "Unknown Item").replace(",", ""));
        System.out.println("Amount is : " + Amount);


        if (Amount > 0 && Amount >= amount) {

          int newAmount = Amount - amount;


          item.asObject().set("initialBalance", Integer.toString(newAmount));
          String write = object.toString();
          FileWriteToCore FRTC = new FileWriteToCore(write);
          FRTC.FileToString();

//                log success withdraw
//                System.out.println("log success withdraw"+newAmount+"  "+Amount+"  "+amount);

        } else {
          //               not enough money
          System.out.println("not enough money");

        }
      }

    }

  } else {

    System.out.println("command not found ");
  }


//
  String test = "done" + " \n";
  //Sending the response back to the client.
  dos.writeUTF(test);
  System.out.println("Message respond to the client for socket " + socket + "  for if \n"+id);
  dos.flush();

  socket.close();

}else{

  System.out.println("here is in else "+sync+" from id "+id);

  int newId=Integer.parseInt(depositId);

  if(!isSnchronized[newId]) {
    isSnchronized[newId]=true;

    System.out.println("2-here is in if isSnchronized for id "+newId+" from "+ id);



    if (command.equals("deposit")) {
//      System.out.println(" deposit command");

      for (JsonValue item : deposits) {
        String idInCore = item.asObject().getString("id", "Unknown Item");


        if (idInCore.equals(depositId)) {

          int newAmount = amount + Integer.parseInt(item.asObject().getString("initialBalance", "Unknown Item").replace(",", ""));
          int upperBound = Integer.parseInt(item.asObject().getString("upperBound", "Unknown Item").replace(",", ""));
          if (newAmount <= upperBound) {

            item.asObject().set("initialBalance", Integer.toString(newAmount));
            String write = object.toString();
            FileWriteToCore FRTC = new FileWriteToCore(write);
            FRTC.FileToString();

//            System.out.println("log success add");
          } else {
//            System.out.println("log upper bound illegal");

          }

        }

      }

    } else if (command.equals("withdraw")) {
//      System.out.println("withdraw");

      for (JsonValue item : deposits) {
        String idInCore = item.asObject().getString("id", "Unknown Item");


        if (idInCore.equals(depositId)) {

          int Amount = Integer.parseInt(item.asObject().getString("initialBalance", "Unknown Item").replace(",", ""));
          System.out.println("Amount is : " + Amount);


          if (Amount > 0 && Amount >= amount) {

            int newAmount = Amount - amount;


            item.asObject().set("initialBalance", Integer.toString(newAmount));
            String write = object.toString();
            FileWriteToCore FRTC = new FileWriteToCore(write);
            FRTC.FileToString();

//                log success withdraw
//                System.out.println("log success withdraw"+newAmount+"  "+Amount+"  "+amount);

          } else {
            //               not enough money
//            System.out.println("not enough money");

          }
        }

      }

    } else {

      System.out.println("command not found ");
    }


//
    String test = "done"+" \n";
    //Sending the response back to the client.
    dos.writeUTF(test);
    System.out.println("Message respond to the client for socket " + socket +"   "+test+"   for id "+id);
    dos.flush();

    socket.close();

    isSnchronized[newId]=false;
  }
  else{
    System.out.println("//////////////////////////////////////////////////////Thread send for sleep for 10 ms for id "+newId+" from "+id+" msg is "+msg + " port "+this.socket);

//    dos.writeUTF("sleep"+" \n");
          TimeUnit.MILLISECONDS.sleep(10);
    System.out.println("call run again for id  "+newId+" from "+id+" msg is "+msg);

    run();


//    sleep(10);
  }

}

      } catch (IOException e) {
        e.printStackTrace();
      } catch (InterruptedException e) {
        e.printStackTrace();
      }

  }
}
