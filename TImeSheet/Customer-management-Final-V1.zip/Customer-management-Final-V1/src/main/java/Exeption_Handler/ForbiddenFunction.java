package Exeption_Handler;

public class ForbiddenFunction extends Exception {
  public ForbiddenFunction() {
  }

  public ForbiddenFunction(String function) {
    super("Function : " + function + " not define ");
  }
}
