package Exeption_Handler;

public class CheckForbiddenFunction extends ForbiddenFunction {
  public CheckForbiddenFunction(){}
  public CheckForbiddenFunction(String function) throws ForbiddenFunction {
    if (function.equals("test") ) {
    } else {
      throw new ForbiddenFunction(function);
    }
  }


}
