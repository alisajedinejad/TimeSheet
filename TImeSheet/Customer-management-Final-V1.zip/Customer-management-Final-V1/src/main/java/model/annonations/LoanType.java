package model.annonations;

import javax.persistence.*;
import java.util.List;

/**
 * Created by ali on 23/03/2020.
 */

@Entity
public class LoanType {




    @OneToMany(mappedBy = "loanType")
//    @JoinColumn(nullable = false)
    private List<GrandCondition> grandCondition;

    @Id
    @Column(name = "typeName", updatable = true, nullable = false)
    private String typeName;

    private int intrest;


    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public int getIntrest() {
        return intrest;
    }

    public void setIntrest(int intrest) {
        this.intrest = intrest;
    }

    public List<GrandCondition> getGrandCondition() {
        return grandCondition;
    }

    public void setGrandCondition(List<GrandCondition> grandCondition) {
        this.grandCondition = grandCondition;
    }

    @Override
    public String toString() {
        return "LoanType{" +
//                "id=" + id +
//                ", grandCondition=" + grandCondition +
                ", typeName='" + typeName + '\'' +
                ", intrest=" + intrest +
                '}';
    }
}
