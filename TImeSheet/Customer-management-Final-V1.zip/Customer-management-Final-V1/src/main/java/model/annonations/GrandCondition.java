package model.annonations;

import javax.persistence.*;

/**
 * Created by ali on 23/03/2020.
 */
@Entity
public class GrandCondition {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false, nullable = false)
    private int id;

    @ManyToOne
    @JoinColumn(nullable = false)

    private LoanType loanType;



    private String conditionName;
    private int minimumTime;
    private int maximumTime;
    private String minimumFee;
    private String maximumFee;

    public GrandCondition(){
        this.loanType=null;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getConditionName() {
        return conditionName;
    }

    public void setConditionName(String conditionName) {
        this.conditionName = conditionName;
    }

    public int getMinimumTime() {
        return minimumTime;
    }

    public void setMinimumTime(int minimumTime) {
        this.minimumTime = minimumTime;
    }

    public int getMaximumTime() {
        return maximumTime;
    }

    public void setMaximumTime(int maximumTime) {
        this.maximumTime = maximumTime;
    }

    public String getMinimumFee() {
        return minimumFee;
    }

    public void setMinimumFee(String minimumFee) {
        this.minimumFee = minimumFee;
    }

    public String getMaximumFee() {
        return maximumFee;
    }

    public void setMaximumFee(String maximumFee) {
        this.maximumFee = maximumFee;
    }
    public LoanType getLoanType() {
        return loanType;
    }

    public void setLoanType(LoanType loanType) {
        this.loanType = loanType;
    }

    @Override
    public String toString() {
        return "GrandCondition{" +
                "id=" + id +
                ", loanType=" + loanType +
                ", conditionName='" + conditionName + '\'' +
                ", minimumTime=" + minimumTime +
                ", maximumTime=" + maximumTime +
                ", minimumFee=" + minimumFee +
                ", maximumFee=" + maximumFee +
                '}';
    }
}
