package model.annonations;

import javax.persistence.*;

/**
 * Created by ali on 19/03/2020.
 */




@Entity
public class Haghighi extends Customer{

    private String meliCode;

    private UserSpecifications userSpecifications;

    public UserSpecifications getUserSpecifications() {
        return userSpecifications;
    }

    public void setUserSpecifications(UserSpecifications userSpecifications) {
        this.userSpecifications = userSpecifications;
    }

    @Override
    public String toString() {
        return "Haghighi{" +
                ", meliCode='" + meliCode + '\'' +
                ", userSpecifications=" + userSpecifications +
                '}';
    }

    public String getMeliCode() {
        return meliCode;
    }

    public void setMeliCode(String meliCode) {
        this.meliCode = meliCode;
    }


}
