package model.annonations;

import javax.persistence.*;

/**
 * Created by ali on 19/03/2020.
 */
@Entity
public class Hoghooghi extends Customer{

    private String factoryCode;

    private FacrotySpecifications factorySpecifications;

    @Override
    public String toString() {
        return "Hoghooghi{" +
//                "id=" + id +
                ", factoryCode='" + factoryCode + '\'' +
                ", factorySpecifications=" + factorySpecifications +
                '}';
    }


    public String getFactoryCode() {
        return factoryCode;
    }

    public void setFactoryCode(String factoryCode) {
        this.factoryCode = factoryCode;
    }

    public FacrotySpecifications getFactorySpecifications() {
        return factorySpecifications;
    }

    public void setFactorySpecifications(FacrotySpecifications factorySpecifications) {
        this.factorySpecifications = factorySpecifications;
    }



}
