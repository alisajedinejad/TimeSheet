package model.annonations;

import javax.persistence.Embeddable;

/**
 * Created by ali on 19/03/2020.
 */
@Embeddable

public class FacrotySpecifications {

    private String name;
    private String buildDate;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBuildDate() {
        return buildDate;
    }

    public void setBuildDate(String buildDate) {
        this.buildDate = buildDate;
    }

    @Override
    public String toString() {
        return "FacrotySpecifications{" +
                "name='" + name + '\'' +
                ", buildDate='" + buildDate + '\'' +
                '}';
    }
}
