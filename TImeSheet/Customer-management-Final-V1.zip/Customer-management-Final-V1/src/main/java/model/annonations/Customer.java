package model.annonations;

import javax.persistence.*;
import java.util.List;

/**
 * Created by ali on 19/03/2020.
 */

@Entity
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CustomerCode", updatable = false, nullable = false)
    private int id;

    @OneToMany(mappedBy = "customer",fetch =FetchType.EAGER)
    List<LoanFile> loanFiles;

    public Customer(){
        this.loanFiles=null;
    }
    public List<LoanFile> getLoanFiles() {
        return loanFiles;
    }

    public void setLoanFiles(List<LoanFile> loanFiles) {
        this.loanFiles = loanFiles;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
