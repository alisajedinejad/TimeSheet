package model.annonations;

import javax.persistence.Embeddable;
import javax.persistence.Entity;

/**
 * Created by ali on 19/03/2020.
 */
@Embeddable

public class UserSpecifications {

    private String firstName;
    private String lastName;
    private String fatherName;
    private String birthDay;


    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public String getBirthDay() {
        return birthDay;
    }

    public void setBirthDay(String birthDay) {
        this.birthDay = birthDay;
    }

    @Override
    public String toString() {
        return "UserSpecifications{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", fatherName='" + fatherName + '\'' +
                ", birthDay='" + birthDay + '\'' +
                '}';
    }
}
