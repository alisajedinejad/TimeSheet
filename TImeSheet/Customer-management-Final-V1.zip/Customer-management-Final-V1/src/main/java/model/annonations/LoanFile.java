package model.annonations;

import javax.persistence.*;

/**
 * Created by ali on 24/03/2020.
 */
@Entity
public class LoanFile {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false, nullable = false)
    private int id;

    @OneToOne
    private GrandCondition grandCondition=null;

    @ManyToOne
    @JoinColumn(nullable = false)
    private Customer customer=null;

    public LoanFile(){
        this.customer=null;
        this.grandCondition=null;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public GrandCondition getGrandCondition() {
        return grandCondition;
    }

    public void setGrandCondition(GrandCondition grandCondition) {
        this.grandCondition = grandCondition;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    @Override
    public String toString() {
        return "LoanFile{" +
                "id=" + id +
                ", grandCondition=" + grandCondition +
                ", customer=" + customer +
                '}';
    }
}
