package model.handlers;

import model.annonations.*;
import org.hibernate.Session;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by ali on 21/03/2020.
 */
public class AdditionalModelFunctions {


    public Customer getUniqClass(String tableName, String columnName, String columnValue, Session session) {

        org.hibernate.query.Query query = session.createQuery("from " + tableName + " where " + columnName + "=:columnVal");
        query.setParameter("columnVal", columnValue);
        Customer customer = (Customer) query.uniqueResult();


        return customer;
    }

    public List<Customer> getListOfHoghooghiClasses(String tableName, String columnName, String columnValue, Session session) {

        org.hibernate.query.Query query = session.createQuery("from " + tableName + " where " + columnName + " LIKE :columnVal AND DTYPE="+"Hoghooghi");
        query.setParameter("columnVal", "%" + columnValue + "%");
        List<Customer> customers = query.list();


        return customers;
    }
    public List<Customer> getListOfHoghooghiClassesExact(String tableName, String columnName, String columnValue, Session session) {

        org.hibernate.query.Query query = session.createQuery("from " + tableName + " where " + columnName + " =:columnVal AND DTYPE="+"Hoghooghi");
        query.setParameter("columnVal", "" + columnValue + "");
        List<Customer> customers = query.list();


        return customers;
    }
    public List<Customer> getListOfHaghighiClasses(String tableName, String columnName, String columnValue, Session session) throws IOException {

        org.hibernate.query.Query query = session.createQuery("from " + tableName + " where " + columnName + " LIKE :columnVal AND DTYPE=" + "Haghighi");
        query.setParameter("columnVal", "%" + columnValue + "%");
        List<Customer> customers = query.list();


        return customers;
    }
    public List<Customer> getListOfHaghighiClassesExact(String tableName, String columnName, String columnValue, Session session) {

        org.hibernate.query.Query query = session.createQuery("from " + tableName + " where " + columnName + " =:columnVal AND DTYPE="+"Haghighi");
        query.setParameter("columnVal", "" + columnValue + "");
        List<Customer> customers = query.list();


        return customers;
    }

    public boolean isSelfMeliCode(Session session, int code, String meliCode) {


        Haghighi customer = session.get(Haghighi.class, code);

        String meliCode2 = customer.getMeliCode();

        if (meliCode.equals(meliCode2)) {
            return true;

        } else return false;
    }

    public boolean isSelfFactoryCode(Session session, int code, String factoryCode) {


        Hoghooghi customer = session.get(Hoghooghi.class, code);

        String factoryCode2 = customer.getFactoryCode();

        if (factoryCode.equals(factoryCode2)) {
            return true;

        } else return false;
    }


    public List<LoanType> getAllLoansType(Session session) {

        List<LoanType> loanTypes=new ArrayList<LoanType>();


        org.hibernate.query.Query query = session.createQuery("from LoanType", LoanType.class);
        loanTypes =query.list();




        return  loanTypes;


    }


    public List<GrandCondition> getGrandConditions(Session session,String loanType) {

        List<GrandCondition> grandConditions=new ArrayList<>();


        org.hibernate.query.Query query = session.createQuery("from GrandCondition where loanType_typeName='"+loanType+"'", GrandCondition.class);
        grandConditions =query.list();

        return  grandConditions;


    }



}
