package controller;

import Exeption_Handler.ForbiddenFunction;
import model.annonations.*;
import model.handlers.AdditionalModelFunctions;
//import org.apache.log4j.spi.LoggerFactory;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.json.JSONObject;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

/**
 * Created by ali on 21/12/2019.
 */
@WebServlet("/Main")
public class Main extends HttpServlet {
//    private final org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(Main.class);


    private void processRequest(
            HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ForbiddenFunction {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");
        LogManager logManager = LogManager.getLogManager();
        Logger logger = logManager.getLogger("");
        logger.setLevel(Level.OFF); //could be Level.OFF
    }


    @Override
    protected void doGet(
            HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");
        LogManager logManager = LogManager.getLogManager();
        Logger logger = logManager.getLogger("");
        logger.setLevel(Level.OFF); //could be Level.OFF

    }


    protected void doPost(
            HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        LogManager logManager = LogManager.getLogManager();
        Logger logger = logManager.getLogger("");
        logger.setLevel(Level.OFF); //could be Level.OFF
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");
        String function = request.getParameter("function");
        PrintWriter out = response.getWriter();
        JSONObject jsonObject = null;
        List<Customer> customers = null;
        RequestDispatcher rd;
        boolean newPage = false;

//        System.out.print(function);
//        out.print(function);
//        return;
        switch (function) {
            case "CreateReal":
                jsonObject = CreateReal(request);
                newPage=false;
                break;

            case "CreateLegal":
                jsonObject = CreateLegal(request);
                newPage=false;
                break;

            case "SearchReal":
                customers = SearchReal(request);
                newPage = true;
                if (customers != null) {
                    request.setAttribute("data", customers);
                    rd = request.getRequestDispatcher("presentation/listOfReal.jsp");
                    rd.forward(request, response);
                } else {
                    rd = request.getRequestDispatcher("index.jsp");
                    rd.forward(request, response);
                }
                break;

            case "SearchLegal":
                customers = SearchLegal(request);
                if (customers != null) {
                    request.setAttribute("data", customers);
                    newPage = true;
                    rd = request.getRequestDispatcher("presentation/listOfLegal.jsp");
                    rd.forward(request, response);
                } else {
                    rd = request.getRequestDispatcher("index.jsp");
                    rd.forward(request, response);
                }
                break;

            case "SaveHaghighi":

                jsonObject = SaveReal(request);
                newPage = false;
                break;

            case "SaveHoghooghi":
                jsonObject = SaveHoghooghi(request);
                newPage = false;
                break;

            case "DeleteReal":
                jsonObject = DeleteReal(request);
                newPage = false;
                break;

            case "DeleteLegal":
                jsonObject = DeleteLegal(request);
                newPage = false;
                break;

            case "home":
//                logger.info("in home");
                List<LoanType> loansType = getAllLoanType();
                request.setAttribute("data", loansType);
                rd = request.getRequestDispatcher("presentation/home.jsp");
                rd.forward(request, response);
                newPage = true;
                break;

            case "FetchCustomerData":
                jsonObject = FetchCustomerData(request);
                newPage = false;
                break;

            case "NewLoan":
                NewLoan(request);
                String loanTypeName = request.getParameter("LoanType");
                String loanInterest = request.getParameter("LoanInterest");
                String[] loanTypeToString = new String[2];
                loanTypeToString[0] = loanInterest;
                loanTypeToString[1] = loanTypeName;
                request.setAttribute("data", loanTypeToString);
                List<GrandCondition> grandConditions = getGrandCondition(loanTypeToString[1]);
                request.setAttribute("grandConditions", grandConditions);
                newPage = true;
                rd = request.getRequestDispatcher("presentation/createLoan.jsp");
                rd.forward(request, response);
                break;

            case "CreateLoanFile":
                jsonObject = CreateLoanFile(request);
                newPage = false;
                break;

            case "GetFullDataOfCustomer":
                Customer customer = GetFullDataOfCustomer(request);
                newPage = false;
                break;

            case "CreateLoen":
                String[] loanTypeToString0 = new String[2];
                loanTypeToString0[0] = request.getParameter("IntrestRate");
                if (request.getParameter("other") != "") {
                    loanTypeToString0[1] = request.getParameter("other");
                } else {
                    loanTypeToString0[1] = request.getParameter("LoanType");
                }
                if (loanTypeToString0[0].equals("")) {
                    loanTypeToString0[0] = getIntrest(loanTypeToString0[1]);
                }
                List<GrandCondition> grandConditions1 = getGrandCondition(loanTypeToString0[1]);
                request.setAttribute("data", loanTypeToString0);
                request.setAttribute("grandConditions", grandConditions1);
                newPage = true;
                rd = request.getRequestDispatcher("presentation/createLoan.jsp");
                rd.forward(request, response);
                break;
            case "test":

                Customer c=test(request);
                out.print(c.getLoanFiles());

                newPage = true;
                break;

            default:
                rd = request.getRequestDispatcher("index.jsp");
                rd.forward(request, response);

        }


        if (!newPage) {
            out.print(jsonObject);
        }


    }


//    ------------------------------------------------------------------------------------------------------------------


    private JSONObject CreateReal(HttpServletRequest request) throws IOException {


        JSONObject jsonObject = new JSONObject();

        org.hibernate.cfg.Configuration configuration = new org.hibernate.cfg.Configuration().configure("hibernate.cfg.xml")
                .addAnnotatedClass(Haghighi.class)
                .addAnnotatedClass(Customer.class)
                .addAnnotatedClass(LoanFile.class)
                .addAnnotatedClass(LoanType.class)
                .addAnnotatedClass(GrandCondition.class)
                .setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5InnoDBDialect");


        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        org.hibernate.Transaction transaction = session.beginTransaction();

        String meliCode = (String) request.getParameter("passportCode");


        AdditionalModelFunctions additionalModelFunctions = new AdditionalModelFunctions();
        Customer customers = additionalModelFunctions.getUniqClass("Customer", "meliCode", meliCode, session);


        if (customers == null) {
            String firstName = (String) request.getParameter("firstName");
            String lastName = (String) request.getParameter("lastName");
            String fatherName = (String) request.getParameter("fatherName");
            String birthDay = (String) request.getParameter("birthDayTime");
            UserSpecifications userSpecifications = new UserSpecifications();
            userSpecifications.setBirthDay(birthDay);
            userSpecifications.setLastName(lastName);
            userSpecifications.setFirstName(firstName);
            userSpecifications.setFatherName(fatherName);

            Haghighi haghighi = new Haghighi();
            haghighi.setMeliCode(meliCode);
            haghighi.setUserSpecifications(userSpecifications);

            session.save(haghighi);
            jsonObject.put("result", "done");
            Customer customers2 = additionalModelFunctions.getUniqClass("Customer", "meliCode", meliCode, session);


            jsonObject.put("CustomerCode", customers2.getId());


        } else {

            jsonObject.put("result", "fail");


        }


        transaction.commit();
        session.close();
        return jsonObject;

    }

    private JSONObject CreateLegal(HttpServletRequest request) throws IOException {

        JSONObject jsonObject = new JSONObject();

        org.hibernate.cfg.Configuration configuration = new org.hibernate.cfg.Configuration().configure("hibernate.cfg.xml")
                .addAnnotatedClass(Hoghooghi.class)
                .addAnnotatedClass(Customer.class)
                .addAnnotatedClass(LoanFile.class)
                .addAnnotatedClass(LoanType.class)
                .addAnnotatedClass(GrandCondition.class)
                .setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5InnoDBDialect");


        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        org.hibernate.Transaction transaction = session.beginTransaction();

        String factoryCode = (String) request.getParameter("companyCode");

        AdditionalModelFunctions additionalModelFunctions = new AdditionalModelFunctions();
        Customer customers = additionalModelFunctions.getUniqClass("Customer", "factoryCode", factoryCode, session);

        if (customers == null) {
            String companyName = (String) request.getParameter("companyName");
            String companyTime = (String) request.getParameter("companyDate");
            FacrotySpecifications facrotySpecifications = new FacrotySpecifications();
            facrotySpecifications.setName(companyName);
            facrotySpecifications.setBuildDate(companyTime);

            Hoghooghi hoghooghi = new Hoghooghi();
            hoghooghi.setFactoryCode(factoryCode);
            hoghooghi.setFactorySpecifications(facrotySpecifications);

            session.save(hoghooghi);
            jsonObject.put("result", "done");
            Customer customers2 = additionalModelFunctions.getUniqClass("Customer", "factoryCode", factoryCode, session);

            jsonObject.put("factoryCode", customers2.getId());


        } else {

            jsonObject.put("result", "fail");


        }


        transaction.commit();
        session.close();
        return jsonObject;


    }

    private List<Customer> SearchReal(HttpServletRequest request) throws IOException {
        request.setCharacterEncoding("UTF-8");
        List<Customer> customers = null;

        String firstName = (String) request.getParameter("SfirstName");
        String lastName = (String) request.getParameter("SlastName");
        String passportCode = (String) request.getParameter("SpassportCode");
        String customerCode = (String) request.getParameter("ScustomerCode");
        org.hibernate.cfg.Configuration configuration = new org.hibernate.cfg.Configuration().configure("hibernate.cfg.xml")
                .addAnnotatedClass(Haghighi.class)
                .addAnnotatedClass(Customer.class)
                .addAnnotatedClass(LoanFile.class)
                .addAnnotatedClass(LoanType.class)
                .addAnnotatedClass(GrandCondition.class)
                .setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5InnoDBDialect");

        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        org.hibernate.Transaction transaction = session.beginTransaction();


        if (!firstName.equals("")) {
            AdditionalModelFunctions additionalModelFunctions = new AdditionalModelFunctions();
            customers = additionalModelFunctions.getListOfHaghighiClasses("Customer", "firstName", firstName, session);


        } else if (!lastName.equals("")) {

            AdditionalModelFunctions additionalModelFunctions = new AdditionalModelFunctions();

            customers =additionalModelFunctions.getListOfHaghighiClasses("Customer", "lastName", lastName, session);

        } else if (!passportCode.equals("")) {
            AdditionalModelFunctions additionalModelFunctions = new AdditionalModelFunctions();

            customers = additionalModelFunctions.getListOfHaghighiClassesExact("Customer", "meliCode", passportCode, session);


        } else if (!customerCode.equals("")) {
            AdditionalModelFunctions additionalModelFunctions = new AdditionalModelFunctions();

            customers = additionalModelFunctions.getListOfHaghighiClassesExact("Customer", "CustomerCode", customerCode, session);

        }
        transaction.commit();
        session.close();
        return customers;


    }

    private List<Customer> SearchLegal(HttpServletRequest request) {
        List<Customer> customers = null;

        String companytName = (String) request.getParameter("ScompanytName");
        String companyCode = (String) request.getParameter("ScompanyCode");
        String customerCode = (String) request.getParameter("realCode");
        org.hibernate.cfg.Configuration configuration = new org.hibernate.cfg.Configuration().configure("hibernate.cfg.xml")
                .addAnnotatedClass(Hoghooghi.class)
                .addAnnotatedClass(Customer.class)
                .addAnnotatedClass(LoanFile.class)
                .addAnnotatedClass(LoanType.class)
                .addAnnotatedClass(GrandCondition.class)
                .setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5InnoDBDialect");

        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        org.hibernate.Transaction transaction = session.beginTransaction();


        if (!companytName.equals("")) {

            AdditionalModelFunctions additionalModelFunctions = new AdditionalModelFunctions();

            customers = additionalModelFunctions.getListOfHoghooghiClasses("Customer", "name", companytName, session);


        } else if (!companyCode.equals("")) {

            AdditionalModelFunctions additionalModelFunctions = new AdditionalModelFunctions();

            customers = additionalModelFunctions.getListOfHoghooghiClassesExact("Customer", "factoryCode", companyCode, session);


        } else if (!customerCode.equals("")) {
            AdditionalModelFunctions additionalModelFunctions = new AdditionalModelFunctions();

            customers = additionalModelFunctions.getListOfHoghooghiClassesExact("Customer", "CustomerCode", customerCode, session);


        }

//
        transaction.commit();
        session.close();
        return customers;


    }

    private JSONObject SaveReal(HttpServletRequest request) throws IOException {


        JSONObject jsonObject = new JSONObject();

        org.hibernate.cfg.Configuration configuration = new org.hibernate.cfg.Configuration().configure("hibernate.cfg.xml")
                .addAnnotatedClass(Haghighi.class)
                .addAnnotatedClass(Customer.class)
                .addAnnotatedClass(LoanFile.class)
                .addAnnotatedClass(LoanType.class)
                .addAnnotatedClass(GrandCondition.class)
                .setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5InnoDBDialect");


        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        org.hibernate.Transaction transaction = session.beginTransaction();

        String meliCode = (String) request.getParameter("meli");
        String codeString = (request.getParameter("code"));

        int code = Integer.parseInt(codeString);


        AdditionalModelFunctions additionalModelFunctions = new AdditionalModelFunctions();
        Customer customers = additionalModelFunctions.getUniqClass("Customer", "meliCode", meliCode, session);


        if (customers == null) {

            Haghighi user = session.get(Haghighi.class, code);

            String firstName = (String) request.getParameter("name");
            String lastName = (String) request.getParameter("family");
            String fatherName = (String) request.getParameter("father");
            String birthDay = (String) request.getParameter("birth");
            UserSpecifications userSpecifications = new UserSpecifications();
            userSpecifications.setBirthDay(birthDay);
            userSpecifications.setLastName(lastName);
            userSpecifications.setFirstName(firstName);
            userSpecifications.setFatherName(fatherName);

            user.setMeliCode(meliCode);
            user.setUserSpecifications(userSpecifications);

            session.update(user);
            jsonObject.put("result", "done");

        } else if (additionalModelFunctions.isSelfMeliCode(session, code, meliCode)) {


            Haghighi user = session.get(Haghighi.class, code);

            String firstName = (String) request.getParameter("name");
            String lastName = (String) request.getParameter("family");
            String fatherName = (String) request.getParameter("father");
            String birthDay = (String) request.getParameter("birth");
            UserSpecifications userSpecifications = new UserSpecifications();
            userSpecifications.setBirthDay(birthDay);
            userSpecifications.setLastName(lastName);
            userSpecifications.setFirstName(firstName);
            userSpecifications.setFatherName(fatherName);

            user.setMeliCode(meliCode);
            user.setUserSpecifications(userSpecifications);

            session.update(user);
            jsonObject.put("result", "done");


        } else {
            jsonObject.put("result", "fail");
        }


        transaction.commit();
        session.close();
        return jsonObject;

//        out.print(customers.getClass());

    }

    private JSONObject SaveHoghooghi(HttpServletRequest request) throws IOException {

        JSONObject jsonObject = new JSONObject();

        org.hibernate.cfg.Configuration configuration = new org.hibernate.cfg.Configuration().configure("hibernate.cfg.xml")
                .addAnnotatedClass(Hoghooghi.class)
                .addAnnotatedClass(Customer.class)
                .addAnnotatedClass(LoanFile.class)
                .addAnnotatedClass(LoanType.class)
                .addAnnotatedClass(GrandCondition.class)
                .setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5InnoDBDialect");


        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        org.hibernate.Transaction transaction = session.beginTransaction();

        String number = (String) request.getParameter("number");
        String codeString = (request.getParameter("code"));

        int code = Integer.parseInt(codeString);

        AdditionalModelFunctions additionalModelFunctions = new AdditionalModelFunctions();
        Customer customers = additionalModelFunctions.getUniqClass("Customer", "factoryCode", number, session);

        if (customers == null) {

            Hoghooghi user = session.get(Hoghooghi.class, code);

            String name = (String) request.getParameter("name");
            String build = (String) request.getParameter("build");
            FacrotySpecifications facrotySpecifications = new FacrotySpecifications();
            facrotySpecifications.setBuildDate(build);
            facrotySpecifications.setName(name);

            user.setFactoryCode(number);
            user.setFactorySpecifications(facrotySpecifications);

            session.update(user);
            jsonObject.put("result", "done");

        } else if (additionalModelFunctions.isSelfFactoryCode(session, code, number)) {


            Hoghooghi user = session.get(Hoghooghi.class, code);

            String name = (String) request.getParameter("name");
            String build = (String) request.getParameter("build");
            FacrotySpecifications facrotySpecifications = new FacrotySpecifications();
            facrotySpecifications.setName(name);
            facrotySpecifications.setBuildDate(build);

            user.setFactoryCode(number);
            user.setFactorySpecifications(facrotySpecifications);

            session.update(user);
            jsonObject.put("result", "done");


        } else {
            jsonObject.put("result", "fail");
        }

        transaction.commit();
        session.close();
        return jsonObject;

    }

    private JSONObject DeleteReal(HttpServletRequest request) throws IOException {


        JSONObject jsonObject = new JSONObject();

        org.hibernate.cfg.Configuration configuration = new org.hibernate.cfg.Configuration().configure("hibernate.cfg.xml")
                .addAnnotatedClass(Haghighi.class)
                .addAnnotatedClass(Customer.class)
                .addAnnotatedClass(LoanFile.class)
                .addAnnotatedClass(LoanType.class)
                .addAnnotatedClass(GrandCondition.class)
                .setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5InnoDBDialect");


        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        org.hibernate.Transaction transaction = session.beginTransaction();

        String codeString = (request.getParameter("code"));

        int code = Integer.parseInt(codeString);

        Haghighi customer = session.get(Haghighi.class, code);

        session.remove(customer);
        jsonObject.put("result", "done");


        transaction.commit();
        session.close();
        return jsonObject;

//        out.print(customers.getClass());

    }

    private JSONObject DeleteLegal(HttpServletRequest request) throws IOException {


        JSONObject jsonObject = new JSONObject();

        org.hibernate.cfg.Configuration configuration = new org.hibernate.cfg.Configuration().configure("hibernate.cfg.xml")
                .addAnnotatedClass(Hoghooghi.class)
                .addAnnotatedClass(Customer.class)
                .addAnnotatedClass(LoanFile.class)
                .addAnnotatedClass(LoanType.class)
                .addAnnotatedClass(GrandCondition.class)
                .setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5InnoDBDialect");


        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        org.hibernate.Transaction transaction = session.beginTransaction();

        String codeString = (request.getParameter("code"));

        int code = Integer.parseInt(codeString);

        Hoghooghi customer = session.get(Hoghooghi.class, code);

        session.remove(customer);
        jsonObject.put("result", "done");


        transaction.commit();
        session.close();
        return jsonObject;

//        out.print(customers.getClass());

    }

    private void NewLoan(HttpServletRequest request) throws IOException {


        JSONObject jsonObject = new JSONObject();

        org.hibernate.cfg.Configuration configuration = new org.hibernate.cfg.Configuration().configure("hibernate.cfg.xml")
                .addAnnotatedClass(LoanType.class)
                .addAnnotatedClass(GrandCondition.class)
                .addAnnotatedClass(LoanFile.class)
                .addAnnotatedClass(Customer.class)

                .setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5InnoDBDialect");


        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        org.hibernate.Transaction transaction = session.beginTransaction();

        String meliCode = (String) request.getParameter("passportCode");


        AdditionalModelFunctions additionalModelFunctions = new AdditionalModelFunctions();
        String loanTypeName = request.getParameter("LoanType");
        int loanInterest = Integer.parseInt(request.getParameter("LoanInterest"));
        String grandConditionName = request.getParameter("LoanName");
        String minTime = request.getParameter("MinTime");
        String maxTime = request.getParameter("MaxTime");
        String maxFee = request.getParameter("MaxFee");
        String minFee = request.getParameter("MinFee");


        GrandCondition grandCondition = new GrandCondition();

        grandCondition.setConditionName(grandConditionName);
        grandCondition.setMaximumFee(maxFee);
        grandCondition.setMinimumFee(minFee);
        grandCondition.setMinimumTime(Integer.parseInt(minTime));
        grandCondition.setMaximumTime(Integer.parseInt(maxTime));

        List<GrandCondition> grandConditionList = new ArrayList<>();

        grandConditionList.add(grandCondition);


        LoanType loanType = session.get(LoanType.class, loanTypeName);


        if (loanType == null) {
            LoanType newLoanType = new LoanType();
            newLoanType.setIntrest(loanInterest);
            newLoanType.setTypeName(loanTypeName);
            newLoanType.setGrandCondition(grandConditionList);
            grandCondition.setLoanType(newLoanType);
            session.save(newLoanType);
            session.save(grandCondition);

        } else {

            grandCondition.setLoanType(loanType);
            loanType.setGrandCondition(grandConditionList);
            session.save(grandCondition);


        }


        transaction.commit();
        session.close();

//        out.print(customers.getClass());

    }

    private List<LoanType> getAllLoanType() throws IOException {


        JSONObject jsonObject = new JSONObject();

        org.hibernate.cfg.Configuration configuration = new org.hibernate.cfg.Configuration().configure("hibernate.cfg.xml")
                .addAnnotatedClass(LoanType.class)
                .addAnnotatedClass(GrandCondition.class)
                .addAnnotatedClass(LoanFile.class)
                .addAnnotatedClass(Customer.class)
                .setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5InnoDBDialect");


        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        org.hibernate.Transaction transaction = session.beginTransaction();


        AdditionalModelFunctions additionalModelFunctions = new AdditionalModelFunctions();

        List<LoanType> loanTypes = additionalModelFunctions.getAllLoansType(session);


        transaction.commit();
        session.close();
        return loanTypes;

//        out.print(customers.getClass());

    }

    private String getIntrest(String typeName) throws IOException {


        JSONObject jsonObject = new JSONObject();

        org.hibernate.cfg.Configuration configuration = new org.hibernate.cfg.Configuration().configure("hibernate.cfg.xml")
                .addAnnotatedClass(LoanType.class)
                .addAnnotatedClass(GrandCondition.class)
                .addAnnotatedClass(LoanFile.class)
                .addAnnotatedClass(Customer.class)
                .setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5InnoDBDialect");


        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        org.hibernate.Transaction transaction = session.beginTransaction();


        LoanType loanTypes = session.get(LoanType.class, typeName);

        String resualt = Integer.toString(loanTypes.getIntrest());


        transaction.commit();
        session.close();
        return resualt;

//        out.print(customers.getClass());

    }

    private List<GrandCondition> getGrandCondition(String typeName) throws IOException {

        JSONObject jsonObject = new JSONObject();

        org.hibernate.cfg.Configuration configuration = new org.hibernate.cfg.Configuration().configure("hibernate.cfg.xml")
                .addAnnotatedClass(LoanType.class)
                .addAnnotatedClass(GrandCondition.class)
                .addAnnotatedClass(LoanFile.class)
                .addAnnotatedClass(Customer.class)
                .setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5InnoDBDialect");


        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        org.hibernate.Transaction transaction = session.beginTransaction();


        AdditionalModelFunctions additionalModelFunctions = new AdditionalModelFunctions();

        List<GrandCondition> grandConditions = additionalModelFunctions.getGrandConditions(session, typeName);


        transaction.commit();
        session.close();
        return grandConditions;

//        out.print(customers.getClass());

    }

    private JSONObject FetchCustomerData(HttpServletRequest request) throws IOException {


        JSONObject jsonObject = new JSONObject();

        org.hibernate.cfg.Configuration configuration = new org.hibernate.cfg.Configuration().configure("hibernate.cfg.xml")
                .addAnnotatedClass(Haghighi.class)
                .addAnnotatedClass(Customer.class)
                .addAnnotatedClass(LoanType.class)
                .addAnnotatedClass(GrandCondition.class)
                .addAnnotatedClass(LoanFile.class)
                .setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5InnoDBDialect");


        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        org.hibernate.Transaction transaction = session.beginTransaction();

        String codeString = (request.getParameter("code"));

        int code = Integer.parseInt(codeString);

        Haghighi customer = session.get(Haghighi.class, code);


        if (customer != null) {
            jsonObject.put("result", "done");

            jsonObject.put("name", customer.getUserSpecifications().getFirstName());
            jsonObject.put("family", customer.getUserSpecifications().getLastName());
            jsonObject.put("fatherName", customer.getUserSpecifications().getFatherName());
            jsonObject.put("birthday", customer.getUserSpecifications().getBirthDay());
            jsonObject.put("meliCode", customer.getMeliCode());
        } else {
            jsonObject.put("result", "fail");

        }

        transaction.commit();
        session.close();
        return jsonObject;

//        out.print(customers.getClass());

    }

    private JSONObject CreateLoanFile(HttpServletRequest request) throws IOException {


        JSONObject jsonObject = new JSONObject();
//        PrintWriter out = response.getWriter();

        org.hibernate.cfg.Configuration configuration = new org.hibernate.cfg.Configuration().configure("hibernate.cfg.xml")
                .addAnnotatedClass(Haghighi.class)
                .addAnnotatedClass(Customer.class)
                .addAnnotatedClass(LoanFile.class)
                .addAnnotatedClass(LoanType.class)
                .addAnnotatedClass(GrandCondition.class)
                .setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5InnoDBDialect");


        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        org.hibernate.Transaction transaction = session.beginTransaction();

        AdditionalModelFunctions additionalModelFunctions = new AdditionalModelFunctions();

        String loanType = (request.getParameter("loanType"));
        String loanTime = (request.getParameter("loanTime"));
        String loanFee = (request.getParameter("loanFee"));
        String customerCode = (request.getParameter("customerCode"));
        int customerCodeToInt = Integer.parseInt(customerCode);
        BigInteger requestFee = new BigInteger(loanFee);
        int requestTime = Integer.parseInt(loanTime);


        List<GrandCondition> grandConditions = additionalModelFunctions.getGrandConditions(session, loanType);


        GrandCondition grandCondition = new GrandCondition();

//        out.print("grandConditions.size()"+grandConditions.size()+"<br>");
//        out.print("loanType"+loanType+"<br>");
//        out.print("loanTime"+loanTime+"<br>");
//        out.print("loanFee"+loanFee+"<br>");
//        out.print("customerCode"+customerCode+"<br>");
//        out.print("customerCodeToInt"+customerCodeToInt+"<br>");
//        out.print("requestFee"+requestFee+"<br>");
//        out.print("requestTime"+requestTime+"<br>");
//        out.print("salammm"++"<br>");
//        out.print("salammm"++"<br>");
//        out.print("salammm"++"<br>");


        for (int i = 0; i < grandConditions.size(); i++) {
            String minFeeToString = grandConditions.get(i).getMinimumFee();
            String maxFeeToString = grandConditions.get(i).getMaximumFee();
            BigInteger minfee = new BigInteger(minFeeToString);
            BigInteger maxfee = new BigInteger(maxFeeToString);
//>=
            if (requestFee.compareTo(minfee) == 0 || requestFee.compareTo(minfee) == 1) {

                if (requestFee.compareTo(maxfee) == 0 || requestFee.compareTo(maxfee) == -1) {
                    if (requestTime >= grandConditions.get(i).getMinimumTime() && requestTime <= grandConditions.get(i).getMaximumTime()) {
                        grandCondition = grandConditions.get(i);
                        LoanFile loanFile = new LoanFile();
                        loanFile.setGrandCondition(grandCondition);
                        loanFile.setCustomer(session.get(Customer.class, customerCodeToInt));

                        session.save(loanFile);
                        transaction.commit();
                        session.close();
                        jsonObject.put("result", "done");
                        return jsonObject;


                    }
                }
            }
        }

        jsonObject.put("result", "fail");
        transaction.commit();
        session.close();
        return jsonObject;

//        out.print(customers.getClass());

    }

    private Customer GetFullDataOfCustomer(HttpServletRequest request) throws IOException {

        org.hibernate.cfg.Configuration configuration = new org.hibernate.cfg.Configuration().configure("hibernate.cfg.xml")
                .addAnnotatedClass(Hoghooghi.class)
                .addAnnotatedClass(Haghighi.class)
                .addAnnotatedClass(Customer.class)
                .addAnnotatedClass(LoanFile.class)
                .addAnnotatedClass(LoanType.class)
                .addAnnotatedClass(GrandCondition.class)
                .setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5InnoDBDialect");

        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        org.hibernate.Transaction transaction = session.beginTransaction();

        int id = Integer.parseInt(request.getParameter("id"));

        Customer customer = session.get(Customer.class, id);


        transaction.commit();
        session.close();
        return customer;
    }

    private Customer test(HttpServletRequest request) throws IOException {


        JSONObject jsonObject = new JSONObject();

        org.hibernate.cfg.Configuration configuration = new org.hibernate.cfg.Configuration().configure("hibernate.cfg.xml")
                .addAnnotatedClass(Hoghooghi.class)
                .addAnnotatedClass(Haghighi.class)
                .addAnnotatedClass(Customer.class)
                .addAnnotatedClass(LoanFile.class)
                .addAnnotatedClass(LoanType.class)
                .addAnnotatedClass(GrandCondition.class)
                .addAnnotatedClass(FacrotySpecifications.class)
                .addAnnotatedClass(UserSpecifications.class)
                .setProperty("hibernate.dialect", "org.hibernate.dialect.MySQL5InnoDBDialect");


        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        org.hibernate.Transaction transaction = session.beginTransaction();

        Customer customer = new Customer();
        customer=session.get(Customer.class,1);


        transaction.commit();
        session.close();
        return customer;

//        out.print(customers.getClass());

    }
//    ------------------------------------------------------------------------------------------------------------------

}
