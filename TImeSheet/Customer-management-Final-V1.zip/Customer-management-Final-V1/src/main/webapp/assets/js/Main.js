/**
 * Created by ali on 24/12/2019.
 */

function createAli(e) {
    if (e == 1) {
        $("#menu5,#menu4,#menu6,#menu7,#menu8").hide();
        $("#menu3,#menu2").show();
        $("#line2").addClass('select');
        $("#line3,#line4,#line5").removeClass('select');
    }
    else if (e == 2) {
        $("#menu5,#menu4").show();
        $("#menu3,#menu2,#menu6,#menu7,#menu8").hide();
        $("#line3").addClass('select');
        $("#line2,#line4,#line5").removeClass('select');
    }
    else if (e == 3) {
        //$('.load').show();
        $("#menu5,#menu4,#menu8").hide();
        $("#menu3,#menu2,#menu7").hide();
        $("#menu6").show();
        $("#line4").addClass('select');
        $("#line2,#line3,#line5").removeClass('select');


    } else if (e == 4) {
        $("#menu5,#menu4,#menu8").hide();
        $("#menu3,#menu2,#menu6").hide();
        $("#menu7").show();
        $("#line5").addClass('select');
        $("#line2,#line3,#line4").removeClass('select');
    }
}


function createReal() {

    $('.load').show();

    var firstName = $("#firstName").val();
    var lastName = $("#lastName").val();
    var fatherName = $("#fatherName").val();
    var passportCode = $("#passportCode").val();
    var birthDayTime = $("#birthDayTime").val();

    //alert(fatherName+lastName+fatherName+passportCode+birthDayTime)

    if (!checkMeliCode(passportCode)) {

        alert("لطفا کد ملی صحیح وارد کنید");

    }
    else {

        $.ajax({
            url: "/Main",
            type: "POST",
            data: {

                function: "CreateReal",
                firstName: firstName,
                lastName: lastName,
                fatherName: fatherName,
                passportCode: passportCode,
                birthDayTime: birthDayTime

            },
            success: function (response) {
                $('.load').hide();

                response = JSON.parse(response);
                console.log(response)

                if (response['result'] == "fail") {
                    alert("این کد ملی قبلا وارد شده");
                }
                else {

                    alert("مشتری جدید با موفقیت ثبت شد کد مشتری  : " + response["CustomerCode"]);
                    //console.log(response)
                }


            },
            error: function (err) {
                $('.load').hide();

                alert('error');
                alert(err);
            }

        });
    }

}


function createLegal() {

    $('.load').show();

    var companyName = $("#companyName").val();
    var companyCode = $("#companyCode").val();
    var companyDate = $("#companyTime").val();
    //console.log(companyCode)


    $.ajax({
        url: "/Main",
        type: "POST",
        data: {

            function: "CreateLegal",
            companyName: companyName,
            companyCode: companyCode,
            companyDate: companyDate

        },
        success: function (response) {
            $('.load').hide();


            response = JSON.parse(response);
            console.log(response)

            if (response['result'] == "fail") {
                alert("این کد اقتصادی قبلا وارد شده است ");
            }
            else {

                alert("مشتری جدید با موفقیت ثبت شد کد مشتری  : " + response["factoryCode"]);

                //console.log(response);
            }


        },
        error: function (err) {
            $('.load').hide();

            alert('error');
            alert(err);
        }

    });

}


function DeleteReal(e) {


    var code = $("#code" + e).text();
    //alert(code);
    code = code.replace(" ", "");
    console.log(code);
    $.ajax({
        url: "/Main",
        type: "POST",
        data: {


            code: code,
            function: "DeleteReal"


        },
        success: function (response) {

            response = JSON.parse(response);
            console.log(response)

            alert("حذف با موفقیت انجام شد");


        },
        error: function (err) {
            alert('error');
            alert(err);
        }

    });

}


function SaveLegal(e) {


    var name = $("#name" + e + " input").val();
    var number = $("#number" + e + " input").val();
    var build = $("#build" + e + " input").val();
    var code = $("#code" + e).text();
    //console.log(name);
    //console.log(number);
    //console.log(build);
    //console.log(code);
    $.ajax({
        url: "/Main",
        type: "POST",
        data: {

            name: name,
            number: number,
            build: build,
            code: code,
            function: "SaveHoghooghi"


        },
        success: function (response) {

            response = JSON.parse(response);
            console.log(response)

            if (response["result"] == "done") {

                alert("ذخیره شد !");
            }
            else {
                alert("این کد اقتصادی قبلا وارد شده است ");


            }


        },
        error: function (err) {
            alert('error');
            alert(err);
        }

    });

}
function DeleteLegal(e) {


    var code = $("#code" + e).text();
    code = code.replace(" ", "");
    //alert(code);
    $.ajax({
        url: "/Main",
        type: "POST",
        data: {


            code: code,
            function: "DeleteLegal"


        },
        success: function (response) {

            response = JSON.parse(response);
            console.log(response)

            alert("حذف با موفقیت انجام شد");


        },
        error: function (err) {
            alert('error');
            alert(err);
        }

    });

}
function otherLoan(e) {
    if ($("#loanType").find(":selected").val() == "other") {
        //$('#other').css("display","block");
        $('#other').fadeIn(200);
        $("#15 , #l5p").show();

    }
    else {
        $('#other').fadeOut(200);
        $("#15 , #l5p").hide();

    }

    //$('#other').show();
}
function Loan(e) {
    if (e == 1) {

        $("#loanTable").hide();


        if ($(".LoanForm").css('display') == "none") {

            $(".LoanForm").slideDown(200);


        }
        else {
            $(".LoanForm").slideUp(200);

        }

    } else if (e == 2) {


        $(".LoanForm").hide();

        if ($("#loanTable").css('display') == "none") {

            $("#loanTable").show();


        }
        else {
            $("#loanTable").hide();
        }
    }
}
function checkLoan() {

    if ($("#LoanName").val() == "" || $("#MinTime").val() == "" || $("#MaxTime").val() == "" || $("#MinFee").val() == "" || $("#MaxFee").val() == "") {
        $(".LoanForm button").hide();

    }
    else {
        $(".LoanForm button").show();
    }


}


function hibernateAjaxGetCustomerData() {

    var id = $("#l0").val();
    if (id == null || id == "") {
        alert("شماره مشتری خالی است");
    }
    else {


        $.ajax({
            url: "/Main",
            type: "POST",
            data: {


                code: id,
                function: "FetchCustomerData"


            },
            success: function (response) {

                response = JSON.parse(response);

                //alert("ok");

                console.log(response);
                if (response['result'] == "done") {

                    $("#l1").text(response["meliCode"]);
                    $("#l2").text(response["name"]);
                    $("#l3").text(response["family"]);
                    $("#l4").text(response["fatherName"]);
                    $("#l5").text(response["birthday"]);
                    $("#menu8").show();
                }



                //
                //var temp = "";
                //for (var i = 0; i < l; i++) {
                //    var arrName = "Type" + i;
                //    if (typeof response[arrName] != "undefined") {
                //        temp += "<option value='" + response[arrName] + "'>" + response[arrName] + "</option>";
                //    }
                //}
                //
                //
                //$("#menu8 select").append(temp);

                else {
                    alert('شماره مشتری  اشتباه است');

                }
            },
            error: function (err) {
                alert('شماره مشتری  اشتباه است');
                //alert(err);
            }

        });


    }


}

function createLoanFile() {

    var loanType = $("#menu8 select").val();
    var loanTime = $("#menu8 #LoanTime").val();
    var loanFee = $("#menu8 #LoanFee").val();
    var customerCode = $("#l0").val();


    if (loanFee == null || loanFee == "" || loanTime == null || loanFee == "") {
        alert("Loan condition can not empty");
    }
    else {
        //alert("here");
        //for(var i=0;i<10;i++){
        //    loanType=loanType.replace(" ","");
        //    loanTime=loanTime.replace(" ","");
        //    loanFee=loanFee.replace(" ","");
        //    customerCode=customerCode.replace(" ","");
        //}

        $.ajax({
            url: "/Main",
            type: "POST",
            data: {


                loanType: loanType,
                loanTime: loanTime,
                loanFee: loanFee,
                customerCode: customerCode,
                function: "CreateLoanFile"


            },
            success: function (response) {

                response=JSON.parse(response);

                console.log(response)

                if(response["result"]=="done"){
                    alert("وام با موفقیت ثبت شد");
                }
                else{
                    alert("وامی با همچین شرایطی وجود ندارد");
                }


            },
            error: function (err) {
                alert('error');
                console.log(err);
            }

        });


    }


}


function SaveReal(e) {
    var name = $("#name" + e + " input").val();
    var family = $("#family" + e + " input").val();
    var father = $("#father" + e + " input").val();
    var birth = $("#birth" + e + " input").val();
    var meli = $("#meli" + e + " input").val();
    var code = $("#code" + e).text();
    $('.load').show();
    code = code.replace(" ", "");
    meli = meli.replace(" ", "");
    meli = meli.replace(" ", "");
    meli = meli.replace(" ", "");
    meli = meli.replace(" ", "");
    meli = meli.replace(" ", "");

    $.ajax({
        url: "/Main",
        type: "POST",
        data: {

            function: "SaveHaghighi",
            name: name,
            family: family,
            father: father,
            birth: birth,
            code: code,
            meli: meli


        },

        success: function (response) {

            response=JSON.parse(response);
            console.log(response["result"])

            if (response["result"] == "done") {

                alert("ذخیره انجام شد");
            }
            else {
                alert("کد ملی تکراری است")

            }

            $('.load').hide();


        },
        error: function (err) {
            $('.load').hide();

            alert('error');
            alert(err);
        }

    });

}


function checkMeliCode(n) {

    if (isNaN(n) || n.toString().length != 10) {
        $('.load').hide();

        return false;
    }
    else {
        var res = n.split("").reverse();
        var samp = 0;
        for (var i = 0; i < 10; i++) {
            if (i != 0) {
                samp += res[i] * (i + 1);

            }
        }

        if (samp % 11 == res[0] || samp % 11 == (11 - res[0])) {
            return true;
        }
        else {
            $('.load').hide();

            return false;
        }

    }


}